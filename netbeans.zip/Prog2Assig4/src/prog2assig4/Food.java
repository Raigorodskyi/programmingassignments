/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Food extends Product {
    private int daysTillExpired;

    public Food(int daysTillExpired) {
        super();
        this.daysTillExpired = 0;
    }

    public Food(int daysTillExpired, String name, double price, int daysInStore) {
        super(name, price, daysInStore);
        this.daysTillExpired = daysTillExpired;
    }

    public Food(int daysTillExpired, Product product) {
        super(product);
        this.daysTillExpired = daysTillExpired;
    }
    
    /**
     * The method checks if the product is expired
     * @return if the product is expired
     */
    public boolean isExpired() {
        return super.getDaysInStore() >= daysTillExpired;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Food other = (Food) obj;
        if (this.daysTillExpired != other.daysTillExpired) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%s %d %s\n", "Should be sold in", daysTillExpired, "days");
        
        return str;
    }

    public int getDaysTillExpired() {
        return daysTillExpired;
    }

    public void setDaysTillExpired(int daysTillExpired) {
        this.daysTillExpired = daysTillExpired;
    }
}
