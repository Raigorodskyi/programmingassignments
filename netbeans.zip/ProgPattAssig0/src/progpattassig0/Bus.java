/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Bus extends Vehicle {
    private int numberOfSeats;

    public Bus(int numberOfSeats, int registrationNumber, double maxVelocity, double value) {
        super(registrationNumber, maxVelocity, value);
        this.numberOfSeats = numberOfSeats;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %d\n", "Number of seats", numberOfSeats);
        
        return str;
    }
    
    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }
}
