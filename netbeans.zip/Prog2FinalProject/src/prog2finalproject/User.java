/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2finalproject;

import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public abstract class User implements Serializable {

    protected String userId;
    protected String password;
    protected String fName;
    protected String lName;

    public User() {
        this.userId = null;
        this.password = "1234";
        this.fName = null;
        this.lName = null;
    }
    
    public User(String password, String fName, String lName) {
        this.password = password;
        this.fName = fName;
        this.lName = lName;
    }

    public User (User user) {
        this.userId = user.userId;
        this.password = user.password;
        this.fName = user.fName;
        this.lName = user.lName;
    }
    
    public static String toCamelCase(String str) {
        String camelCase = "";
        String lowerCase = str.toLowerCase();   // if string is something like hElLO wOrLd
        camelCase += Character.toUpperCase(lowerCase.charAt(0));
        for (int i = 1; i < lowerCase.length(); i++) {
            if (lowerCase.charAt(i - 1) == ' ') {
                camelCase += Character.toUpperCase(lowerCase.charAt(i));
            }else if(lowerCase.charAt(i) != ' ') {
                camelCase += lowerCase.charAt(i);
            }
        }
        return camelCase;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.userId);
        hash = 67 * hash + Objects.hashCode(this.password);
        hash = 67 * hash + Objects.hashCode(this.fName);
        hash = 67 * hash + Objects.hashCode(this.lName);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (!Objects.equals(this.userId, other.userId)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        if (!Objects.equals(this.fName, other.fName)) {
            return false;
        }
        if (!Objects.equals(this.lName, other.lName)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-15s: %s\n", "User ID", userId);
        str += String.format("%-15s: %s\n", "User First Name", fName);
        str += String.format("%-15s: %s\n", "User Last Name", lName);
        
        return str;
    }
    
    public abstract int generateId();

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }
}
