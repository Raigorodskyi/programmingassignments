/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author 2003i
 */
public class Ellipse extends Shape {

    private double majorAxis;
    private double minorAxis;

    public Ellipse() {
        this.majorAxis = 1;
        this.minorAxis = 1;
    }

    public Ellipse(double majorAxis, double minorAxis) {
        this.majorAxis = majorAxis;
        this.minorAxis = minorAxis;
    }

    public Ellipse(Ellipse ellipse) {
        this.majorAxis = ellipse.majorAxis;
        this.minorAxis = ellipse.minorAxis;
    }

    @Override
    public double calcArea() {
        return Math.PI * majorAxis * minorAxis;
    }

    @Override
    public double calcPerimeter() {
        return 2 * Math.PI * Math.sqrt(((majorAxis * majorAxis) + (minorAxis * minorAxis)) / 2);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final Ellipse other = (Ellipse) obj;
        if (Double.doubleToLongBits(this.majorAxis) != Double.doubleToLongBits(other.majorAxis))
            return false;
        if (Double.doubleToLongBits(this.minorAxis) != Double.doubleToLongBits(other.minorAxis))
            return false;
        return true;
    }
    
    
    
    @Override
    public String toString() {
        String str = "";

        str += String.format("%-10s: %.2f\n", "Major axis", majorAxis);
        str += String.format("%-10s: %.2f\n", "Minor axis", minorAxis);

        return str;
    }

    public double getMajorAxis() {
        return majorAxis;
    }

    public void setMajorAxis(double majorAxis) {
        this.majorAxis = majorAxis;
    }

    public double getMinorAxis() {
        return minorAxis;
    }

    public void setMinorAxis(double minorAxis) {
        this.minorAxis = minorAxis;
    }

}
