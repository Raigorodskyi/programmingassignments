/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Employee extends User {
    private double salary;
    private static int employeeId = 0;

    public Employee() {
        super();
        this.salary = 0;
        this.id = String.format("E%04d", generateId());

    }
    
    public Employee(double salary, String id, int point, String name, String gender,
            String phoneNo, String email) {
        super(id, name, gender, phoneNo, email);
        this.salary = salary;
        this.id = String.format("E%04d", generateId());
    }
    
    public Employee(Employee employee) {
        super(employee);
        this.salary = employee.salary;
    }
    
    public static int generateId(){
        return employeeId++;
    }
    
    @Override
    public int calcPoint() {
        return (int) (super.point + (salary/100));  // divided by 100, as it is 1% of the salary
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.salary) ^ 
                (Double.doubleToLongBits(this.salary) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Employee other = (Employee) obj;
        if (Double.doubleToLongBits(this.salary) != Double.doubleToLongBits(other.salary)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %-2f\n", "Salary", salary);
        
        return str;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
} 
