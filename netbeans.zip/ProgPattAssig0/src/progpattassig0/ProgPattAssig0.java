/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;
import java.util.Arrays;
import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 *
 * @author Igor Raigorodskyi
 */
public class ProgPattAssig0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Creating an array with 3 TaxableHouse objects and 3 TaxableBus objects
        Taxable[] taxables = {new TaxableBus(20, 0, 60, 8000), new TaxableBus(40, 1, 80, 9500),
        new TaxableBus(55, 2, 100, 15000), new TaxableHouse(2000, "Montreal", true, 200000), 
        new TaxableHouse(1000, "Blainville", false, 150000),
        new TaxableHouse(1500, "Laval", true, 300000)};
        
        // displaying each object with tax calculated
        System.out.println("Displaying objects info with tax value\n");
        for (Taxable taxable : taxables) {
            System.out.println(taxable);
        }
        
        // sorting the array using lambda expression 
        Arrays.sort(taxables, (first, second) -> {
            return Double.compare(first.valueTax(), second.valueTax());
            });
        // displaying the sorted value
        System.out.println("Displaying objects info sorted by the tax value\n");
        for (Taxable taxable : taxables) {
            System.out.println(taxable);
        }
        
        Student[] students = {new Student("Liam", 87), new Student("Max", 93),
        new Student("Annie", 72), new Student("Andrew", 96), new Student("John", 64)};
        
        System.out.println("Listing student names in reversed order based on the score");
        Stream.of(students).sorted(Comparator.reverseOrder()).
                forEach(e -> System.out.print(e.getName() + "\n"));
       
        System.out.println("Listing 3 student names with highest scores");
        Stream.of(students).sorted(Comparator.reverseOrder()).limit(3).
                forEach(e -> System.out.print(e.getName() + "\n"));
        
        System.out.println("Listing student names starting with the shortest one");
         Stream.of(students).sorted(Comparator.comparingInt(student -> student.getName().
                 length())).forEach(e -> System.out.print(e.getName() + "\n"));
        
        
        System.out.println("Listing student names whose name starts with " + '"' + "Jo" + '"');
        Stream.of(students).filter(student -> student.getName().startsWith("Jo"))
                .forEach(student -> System.out.println(student.getName()));
        
        //Q2
        int[] values = {30, 104, 123, 565, 20, 145, 365, 3, 45, 61}; 
        
        IntSummaryStatistics stats = IntStream.of(values).limit(10).filter(e -> e > 60)
                .summaryStatistics();
        System.out.printf("The summary of the stream is\n%-10s%10d\n" +
        "%-10s%10d\n%-10s%10d\n%-10s%10.2f\n\n", " Max:", stats.getMax(), 
        " Min:", stats.getMin(), " Sum:", stats.getSum(), " Average:", stats.getAverage()); 
        
        // Q4
        System.out.println(String.format("%-15s: %d", "Above or equal average", 
                IntStream.of(values).filter(e  -> e >= stats.getAverage()).count()));
        System.out.println(String.format("%-15s: %d", "Below average", 
                IntStream.of(values).filter(e  -> e < stats.getAverage()).count()));
    }
}




















