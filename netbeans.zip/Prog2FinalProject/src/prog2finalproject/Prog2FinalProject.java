/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2finalproject;

import java.util.ArrayList;

/**
 *
 * @author 2003i
 */
public class Prog2FinalProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //System.out.println(User.class.);

        ArrayList<Double> finalScores = new ArrayList<>();
        double mark = 100;
        finalScores.add(mark);
        //Course course = new Course("Programming 2", 1, teacher, students, finalScores);
        ArrayList<Course> courses = new ArrayList<>();
        Student student = new Student("fvsdf", "Gal", "Gadot", courses);
        Student student2 = new Student("fvsdf", "Gal", "Gadot", courses);
        Student student3 = new Student("fvsdf", "Gal", "Gadot", courses);
        ArrayList<Student> students = new ArrayList<>();
        students.add(student);
        students.add(student2);
        students.add(student3);
        Teacher teacher = new Teacher(courses, "5424", "Anne", "Letourneau");
        Teacher teacher2 = new Teacher(courses, "5424", "Anne", "Letourneau");
        Course course = new Course("Programming 2", 1, teacher, students, finalScores);
        courses.add(course);
        System.out.println(student2.toString());
        System.out.println(student.toString());
        System.out.println(student3.toString());
        System.out.println(course.toString());
        System.out.println(teacher2.toString());
        
    }
    
}
