/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;
import java.util.ArrayList;

/**
 *
 * @author Igor Raigorodskyi
 */
public class BookStore {
    protected static ArrayList<Item> items = new ArrayList<>();
    protected static ArrayList<Employee> employees = new ArrayList<>();
    protected static ArrayList<Customer> customers = new ArrayList<>();
    
    public static void addItem(Item item) {
        int ifIsItemEqual1 = 0;
        for (Item item1 : items) {
            if (item1.equals(item)) {
                ifIsItemEqual1++;
            }
        }
        if (ifIsItemEqual1 == 1) {
            for (Item item1 : items) {
                if (item1.equals(item)) {
                    item1.setAmount(item1.amount + item.getAmount());
                }
            }
        }else {
            items.add(item);
        }
    }
    
    public static void addEmployee(Employee employee) {
        employees.add(employee);
    }
    
    public static void addCustomer(Customer customer) {
        customers.add(customer);
    }
    
    public static ArrayList<Item> searchItem(String keyword) {
        ArrayList<Book> searchedItemsBooks = new ArrayList<>();
        ArrayList<Cd> searchedItemsCds = new ArrayList<>();
        ArrayList<Item> searchedItems = new ArrayList<>();
        // separation of the items into cd and book so we could further check the 
                //keyword in their names
        for (Item item : items) {
            if (item instanceof Book) {
                searchedItemsBooks.add((Book) item);
            }
        }
        for (Item item : items) {
            if (item instanceof Cd) {
                searchedItemsCds.add((Cd) item);
            }
        }
        for (Book searchedItemBook : searchedItemsBooks) {
            if (searchedItemBook.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                searchedItems.add(searchedItemBook);
            }
        }
        for (Cd searchedItemCd : searchedItemsCds) {
            if (searchedItemCd.getName().toLowerCase().contains(keyword.toLowerCase())) {
                searchedItems.add(searchedItemCd);
            }
        } 
        return searchedItems;
    }
    
    public static void payEmployeesPoints() {
        for (Employee employee : employees) {
            employee.setPoint(employee.calcPoint());
        }
    }
}
