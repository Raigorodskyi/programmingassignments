/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;

/**
 *
 * @author Igor Raigorodskyi
 */
public class NonFoodProduct extends Product {

    public NonFoodProduct() {
        super();
    }

    public NonFoodProduct(String name, double price, int daysInStore) {
        super(name, price, daysInStore);
    }

    public NonFoodProduct(Product product) {
        super(product);
    }
}
