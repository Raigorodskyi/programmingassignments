/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2finalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author Igor Raigorodskyi
 */
public class VanierScoreSystem {
    
    protected static ArrayList<User> users = new ArrayList<>();
    protected static ArrayList<Course> courses = new ArrayList<>();
    protected static Admin admin = new Admin("1234", "Igor", "Raigorodskyi");
    
    public static void main(String[] args) {
        users.add(admin);
        System.out.println(admin.toString());
    }
    
    public static void initData() {
        String path = "users.ser";
        String pathCourses = "courses.ser";
        
        File userFile = new File(path);
        File courseFile = new File(pathCourses);
        
        if (userFile.isFile())
            users = (ArrayList<User>) deserializeData(path);
        else
            users = new ArrayList<>();
        
        if (courseFile.isFile()) {
            courses = (ArrayList<Course>) deserializeData(pathCourses);
        }else 
            courses = new ArrayList<>();
    }

    public static void serializeData(String path, Object object) {
        try ( FileOutputStream fos = new FileOutputStream(path)) {
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(object);
        } catch (Exception e) {
        }
    }

    public static Object deserializeData(String path) {
        Object object = null;
        try ( FileInputStream fis = new FileInputStream(path)) {
            ObjectInputStream ois = new ObjectInputStream(fis);
            object = ois.readObject();
        } catch (Exception e) {
            System.out.println(e.getClass() + ": " + e.getMessage());
        }

        return object;
    }
}
