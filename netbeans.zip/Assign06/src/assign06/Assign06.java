/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign06;

import java.util.Random;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Assign06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    }
    
    public static Integer[][] generateRandomMatrix(int row, int col, double upperBound) {
        if (upperBound < 1) {
            upperBound = 10;
        }
        Integer[][] matrix = new Integer[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                Random chance = new Random();
                int random = chance.nextInt(5);
                if (random < 1) {
                    matrix[i][j] = null;
                }else if(random == 1 || random == 2) {
                    Random console = new Random();
                    matrix[i][j] = console.nextInt((int) upperBound);
                }else {
                    Random console = new Random();
                    matrix[i][j] = console.nextInt((int) upperBound) * -1;
                }
            }
        }
        return matrix;
    }
    
    public static String[][] calcResult(Integer[][] numss) throws InvalidNumberException {
        String[][] resultss = new String[numss.length][numss[0].length]; // 0 is just 
                                    // idx of any row because the number of columns is the same everywhere
        Integer[][] numss2 = new Integer[numss.length][numss[0].length]; // this matrix will store 
                                    //values from from right to left, from bottom to top
        // storing the values in reverse to numss2
        for (int i = numss2.length - 1; i >= 0; i--) {
            for (int j = numss2[i].length - 1; j >= 0; j--) {
                numss2[i][j] = numss[numss2.length - 1 - i][numss2[i].length - 1 - j];
            }
        }
        // calculation process
        for (int i = 0; i < numss.length; i++) {
            for (int j = 0; j < numss[i].length; j++) {
                try {
                    if (numss[i][j] < 0) {
                        throw new InvalidNumberException(Double.toString(numss[i][j]));
                    }
                    if (numss2[i][j] < 0) {
                        throw new InvalidNumberException(Double.toString(numss2[i][j]));
                    }
                    if (numss2[i][j] == 0) {
                        throw new ArithmeticException(Double.toString(numss2[i][j]));
                    }
                   Double result = new Double(numss[i][j]) / new Double(numss2[i][j]);
                   resultss[i][j] = String.format("%.2f", result);
                }catch(InvalidNumberException e) {
                    resultss[i][j] = "I";
                }catch(NullPointerException e) {
                    resultss[i][j] = "N";
                }catch(ArithmeticException e) {
                    resultss[i][j] = "A";
                }
            }
        }
        return resultss;
    } 
}
