/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author 2003i
 */
public class Square extends Rectangular implements Drawable {

    public Square() {
        super();
    }

    public Square(double side) {
        super(side, side);
    }

    public Square(Square square) {
        super(square);
    }

    @Override
    public void draw() {
        int lengthCharNum = (int)getLength()*2-2;
        int heightCharNum = (int)getLength()-2;
        
        String str = "+";
        
        for (int i = 0; i < lengthCharNum; i++) {
            str += "-";
        }
        str += "+\n";
        
        for (int i = 0; i < heightCharNum; i++) {
            str += "|";
            for (int j = 0; j < lengthCharNum; j++) {
                str += " ";
            }
            str += "|\n";
        }
        
        str += "+";
        for (int i = 0; i < lengthCharNum; i++) {
            str += "-";
        }
        str += "+\n";
        System.out.println(str);
    }

    @Override
    public String toString() {
        return String.format("%-10s: %.2f\n", "Side", getLength());
    }

    public double getSide() {
        return getLength();
    }

    public void setSide(double side) {
        setHeight(side);
        setLength(side);
    }
    
    public static void main(String[] args) {
        Square square = new Square(34);
        square.draw();
    }
}
