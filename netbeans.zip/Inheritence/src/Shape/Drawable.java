/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author 2003i
 */
public interface Drawable {
//      private String name;        // data member not allow

    public static final String NAME = "";      // static is allow, but it will automatically be a final

    // abstract method allow, and no need for keyword "abstract"
    /**
     * To draw the shape
     */
    public void draw();

    // normal methods allow, with keyword "default"
    public default void printInfor() {
        System.out.println("You can draw this shape.");
    }
}