/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalProj;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Viktor Kostadinov
 */
public class Student {
    Connection con;

    private String studentID;
    private String name;
    private String contactNumber;

    public Student(String studentID, String name, String contactNumber) {
        this.studentID = studentID;
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    @Override
    public String toString() {
        String str = "";
        str += String.format("Student\n  Student ID: %s\n  Student name: %s\n  "
                + "Contact Number: %s\n\n", studentID, name, contactNumber);
        return str;

    }

    /**
     * Base for all search methods that will use this method but vary depending on the reference
     * @param reference depending on what user uses to search for book, title/author name/year
     * @param name the name of the reference, e.g. author's name, the year of publication 
     * @return the list of books that match search requirements
     * @throws Exception 
     */
    public List<Book> searchBook(String reference, String name) throws Exception {
        List<Book> books = new ArrayList<>();
        
        Statement stmt = con.createStatement();
        String query1 =  "SELECT * FROM Books WHERE" + reference + "LIKE" + name + ";";
                ResultSet rs = stmt.executeQuery(query1);
                while (rs.next()) {
                    Book book = null;
                    book.setSN(rs.getString("SN"));
                    book.setTitle(rs.getString("Title"));
                    book.setAuthor(rs.getString("Author"));
                    book.setPublisher(rs.getString("Publisher"));
                    book.setReleaseYear(Integer.parseInt(rs.getString("Year")));
                    book.setPrice(Double.parseDouble(rs.getString("Price")));
                    book.setQuantity(Integer.parseInt(rs.getString("Quantity")));
                    book.setIssuedQuantity(Integer.parseInt(rs.getString("Issued")));
                    book.setDateOfPurchase(rs.getString("AddedDate"));
                    
                    books.add(book);
                }
        return books;
    }
    
    /**
     * Uses searchBook method in order to find books by title
     * @param title the title of the book
     * @return list of matching books
     * @throws Exception 
     */
    public List<Book> searchBookByTitle(String title) throws Exception {
        return searchBook("Title", title);
    }

    /**
     * Uses searchBook method in order to find books by author's name
     * @param name author,s name
     * @return list of matching books
     * @throws Exception 
     */
    public List<Book> searchBookByAuthorName(String name) throws Exception {
        return searchBook("Author", name);
    }

    /**
     * Uses searchBook method in order to find books by year of publication
     * @param year the year of publication of the book 
     * @return list of matching books
     * @throws Exception 
     */
    public List<Book> searchBookByYear(String year) throws Exception {
        return searchBook("Year", year);
    }

    public Map<String, String> viewCatalog() {
        return null;
    }
    
    public List<Book> viewCatalogList() throws Exception {
        List<Book> books = new ArrayList<>();
        
        Statement stmt = con.createStatement();
        String query1 =  "SELECT * FROM Books;";
                ResultSet rs = stmt.executeQuery(query1);
                while (rs.next()) {
                    Book book = null;
                    book.setSN(rs.getString("SN"));
                    book.setTitle(rs.getString("Title"));
                    book.setAuthor(rs.getString("Author"));
                    book.setPublisher(rs.getString("Publisher"));
                    book.setReleaseYear(Integer.parseInt(rs.getString("Year")));
                    book.setPrice(Double.parseDouble(rs.getString("Price")));
                    book.setQuantity(Integer.parseInt(rs.getString("Quantity")));
                    book.setIssuedQuantity(Integer.parseInt(rs.getString("Issued")));
                    book.setDateOfPurchase(rs.getString("AddedDate"));

                    books.add(book);
                }
        return books;
    }

    public Boolean borrow(Book book) {
        return null;
    }

    public Boolean searchBookByTitle(Book book) {
        return null;
    }
}