/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;
import java.util.ArrayList;
import java.util.Objects;
/**
 *
 * @author Igor Raigorodskyi
 */
public class Customer extends User {
    private int vipLevel;
    private ArrayList<Item> itemsInCart = new ArrayList<>();
    private static int nextCustomerId = 0;

    public Customer() {
        super();
        this.vipLevel = 0;
        this.itemsInCart = null;
        this.id = String.format("U%04d", generateId());
    }

    public Customer(int vipLevel, String id, int point, 
            String name, String gender, String phoneNo, String email) {
        super(id, name, gender, phoneNo, email);
        this.vipLevel = vipLevel;
        this.id = String.format("U%04d", generateId());
    }

    public Customer(Customer customer) {
        super(customer);
        this.vipLevel = customer.vipLevel;
    }

    public static int generateId(){
        return nextCustomerId++;
    }
    
    private boolean updateVip() {
         if (vipLevel == 0 || point <= 50) {
            vipLevel++;
            point -= 50;
            return true;
        }
        if (vipLevel == 1 || point <= 100) {
            vipLevel++;
            point -= 100;
            return true;
        }
        if (vipLevel == 2 || point <= 150) {
            vipLevel++;
            point -= 150;
            return true;
        }
        return false;
    } 
    
    public void addItemToCart(Item item, int amount) {
        // copy of the item
        Item itemCopy = new Item(item);
        // setting the amount of the item
        itemCopy.setAmount(amount);
        // adding the item to the itemsInCart
        itemsInCart.add(itemCopy);
    }
    
    public double calcPrice() {
        double price = 0;
        for (Item itemInCart : itemsInCart) {
            price += itemInCart.price * itemInCart.amount;
        }
        return price;
    }
    
    public boolean checkout() {
        for (Item itemInCart : itemsInCart) {
            if (!BookStore.items.contains(itemInCart)) {
                return false;
            }
        }
        calcPrice();
        calcPoint();
        itemsInCart.clear();
        point += calcPoint();
        for (Item itemInCart : itemsInCart) {
            for (Item item : BookStore.items) {
                if (itemInCart.equals(item)) {
                    item.setAmount(item.getAmount() - itemInCart.getAmount());
                }
            }
        }
        return true;
    }
    
    @Override
    public int calcPoint() {
        switch (vipLevel) {
            case 0:
                point += Math.floor(calcPrice());
            case 1:
                point += (int) Math.floor(calcPrice()) * 1.05;
            case 2:
                point += (int) Math.floor(calcPrice()) * 1.10;
            case 3:
                point += (int) Math.floor(calcPrice()) * 1.15;
        }
        if (point >= 200) {
            point += 20;
        }
        return point;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + this.vipLevel;
        hash = 47 * hash + Objects.hashCode(this.itemsInCart);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Customer other = (Customer) obj;
        if (this.vipLevel != other.vipLevel) {
            return false;
        }
        if (!Objects.equals(this.itemsInCart, other.itemsInCart)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %d\n", "VIP level", vipLevel);
        for (int i = 0; i < itemsInCart.size(); i++) {
            str += "Item " + i+1 + ":\n";
            str += itemsInCart.get(i).toString();
        }
        
        return str;
    }
    
    public int getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(int vipLevel) {
        this.vipLevel = vipLevel;
    }

    public ArrayList<Item> getItemsInCart() {
        return itemsInCart;
    }

    public void setItemsInCart(ArrayList<Item> itemsInCart) {
        this.itemsInCart = itemsInCart;
    } 
}
