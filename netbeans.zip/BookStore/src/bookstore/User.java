/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

/**
 *
 * @author Igor Raigorodskyi
 */
public abstract class User extends Person implements Gift{
    protected String id;
    protected int point;

    public User() {
        super();
        this.id = null;
        this.point = 0;
    }

    public User(String id, String name, String gender, String phoneNo, String email) {
        super(name, gender, phoneNo, email);
        this.id = id;
    }

    public User(User user) {
        super(user);
        this.id = user.id;
    }
    
    public abstract int calcPoint();

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.id);
        hash = 37 * hash + this.point;
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (this.point != other.point) {
            return false;
        }
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %s\n", "User ID", id);
        str += String.format("%-15s: %d\n", "Points", point);
        
        return str;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }
    
    @Override
    public boolean pointToGift() {
        Random random = new Random();
        if (point < 50) {
            return false;
        }else {
            point -= 50;
            int randNum = random.nextInt(BookStore.items.size());
            BookStore.items.get(randNum).setAmount
                    (BookStore.items.get(randNum).getAmount()-1);
        }
        return true;
    }
    
    @Override
    public boolean pointToGift(String type) {
        Random random = new Random();
        ArrayList<Book> books = new ArrayList<>();
        ArrayList<Cd> cds = new ArrayList<>();
        if (point < 70) {
            return false;
        } else {
            point -= 70;
            //separating books and cds so we could get the gift from an arraylist
                //of the chosen type
            for (Item item : BookStore.items) {
                if (item instanceof Book) {
                    books.add((Book) item);
                }
            }
            for (Item item : BookStore.items) {
                if (item instanceof Cd) {
                    cds.add((Cd) item);
                }
            }
            if (type.equalsIgnoreCase("Book")) {
                int randNum = random.nextInt(books.size());
                books.get(randNum).setAmount(books.get(randNum).getAmount() - 1);
                // This would clear the whole list of items and it would insert 
                        //all the items with the updated amount of the chosen item
                BookStore.items.clear();
                BookStore.items.addAll(books);
                BookStore.items.addAll(cds);
            } else {
                int randNum = random.nextInt(cds.size());
                cds.get(randNum).setAmount(cds.get(randNum).getAmount() - 1);
                cds.remove(random.nextInt(cds.size()));
                BookStore.items.clear();
                BookStore.items.addAll(books);
                BookStore.items.addAll(cds);
            }
           return true;
        }
    }
    
    @Override
    public boolean pointToGift(Item item) {
        if (point < 100) {
            return false;
        } else {
            point -= 100;
            for (Item item1 : BookStore.items) {
                if (item.equals(item1)) {
                    item1.setAmount(item1.amount - 1);
                }
            }
            return true;
        }
    }
}
