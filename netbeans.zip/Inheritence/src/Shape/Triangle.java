/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author 2003i
 */
public class Triangle extends Shape {
    private double sideA;
    private double sideB;
    private double angleC;

    public Triangle() {
        this.sideA = 1;
        this.sideB = 1;
        this.angleC = 90;
    }
    
    public Triangle(double sideA, double sideB, double angleC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.angleC = angleC;
    }
    
    public Triangle(Triangle triangle) {
        this.sideA = triangle.sideA;
        this.sideB = triangle.sideB;
        this.angleC = triangle.angleC;
    }
    
    @Override
    public double calcArea() {
        return 0.5 * sideA * sideB * Math.sin(Math.toRadians(angleC));
    }
    
    @Override
    public double calcPerimeter() {
        double sideC = Math.sqrt(sideA * sideA + sideB * sideB - 2*sideA*sideB*Math.cos(Math.toRadians(angleC)));
        return sideA + sideB + sideC;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Triangle other = (Triangle) obj;
        if (Double.doubleToLongBits(this.sideA) != Double.doubleToLongBits(other.sideA)) {
            return false;
        }
        if (Double.doubleToLongBits(this.sideB) != Double.doubleToLongBits(other.sideB)) {
            return false;
        }
        if (Double.doubleToLongBits(this.angleC) != Double.doubleToLongBits(other.angleC)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";

        str += String.format("%-10s: %.2f\n", "Side A", sideA);
        str += String.format("%-10s: %.2f\n", "Side B", sideB);
        str += String.format("%-10s: %.2f\n", "Angle", angleC);

        return str;
    }

    public double getSideA() {
        return sideA;
    }

    public void setSideA(double sideA) {
        this.sideA = sideA;
    }

    public double getSideB() {
        return sideB;
    }

    public void setSideB(double sideB) {
        this.sideB = sideB;
    }

    public double getAngleC() {
        return angleC;
    }

    public void setAngleC(double angleC) {
        this.angleC = angleC;
    }
    
    
}
