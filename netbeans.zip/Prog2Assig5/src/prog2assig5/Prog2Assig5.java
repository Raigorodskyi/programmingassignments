/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig5;
import java.util.Random;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Prog2Assig5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    }

    public static void printShape(int row, char symbol) {
        if (row < 1) {
            return;
        }
        for (int i = 0; i < row; i++) {
            System.out.print(symbol + " ");
        }
        System.out.println();
        printShape(row - 1, symbol);
    }

    public static void printShape2(int row, char symbol) {
        if (row < 1) {
            return;
        }
        // general pattern
        String str = "";
        for (int i = 0; i < row; i++) {
            str += symbol + " ";
        }
        printShape2(row - 1, symbol);
        System.out.println(str);
    }
    
    static void printShape3(int totalRow, char symbol, int currentRowId) {
        if (currentRowId == 0) {
            return;
        }
        String str = "";
        int space = (currentRowId * 2) - 2;
        int symbols = (currentRowId * 2) - 1;
        for (int i = 0; i < space; i++) {
            str += " ";
        }
        for (int i = 0; i < symbols; i++) {
            str += symbol + " ";
        }
        System.out.println(str);
        printShape3(totalRow, symbol, currentRowId - 1);
    }
    
    public static int[][] generateMatrix(int row, int col, int boundary1,
            int boundary2, int iteration) {
        // generating matrix and figuring out max and min boundaries
        int[][] matrix = new int[row][col];
        int maxBound = Math.max(boundary1, boundary2);
        int minBound = Math.min(boundary1, boundary2);
        // filling the arrays
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                Random console = new Random();
                matrix[i][j] = console.nextInt(maxBound - minBound) + minBound;
            }
        }
        // calculating the diagonal and subdiagonal sum
        int diagonalSum = 0;
        int subDiagonalSum = 0;
        for (int i = 0; i < col; i++) {
            diagonalSum += matrix[i][i];
        }
        for (int i = 0; i < row; i++) {
            subDiagonalSum += matrix[i][row - i - 1]; // -1 is because we want to get the idx
        }
        // return statements
        if (subDiagonalSum == diagonalSum) {
            return matrix;
        }else if (subDiagonalSum != diagonalSum && iteration > 0) {
            generateMatrix(row, col, boundary1, boundary2, iteration - 1);
        }
        return null;
    }
    
    public static void printShape4(int row, char symbol, int currentRowId) {  
        // figuring out the number of spaces needed befor printing symbols for each row
        int space = 1;  
        space = row - 1;  
        for (int j = 1; j<= row; j++) {  
            for (int i = 1; i<= space; i++) {  
                System.out.print(" ");  
            }  
            space--;  
            for (int i = 1; i <= 2 * j - 1; i++) {  
                System.out.print(symbol + " ");  
            }  
            System.out.println();  
        }  
        space = 1;  
        for (int j = 1; j<= row - 1; j++) {  
            for (int i = 1; i<= space; i++) {  
                System.out.print(" ");  
            }  
            space++;  
            for (int i = 1; i<= 2 * (row - j) - 1; i++) {  
                System.out.print(symbol + " ");  
            }     
            System.out.println();  
        }  
    }  
}
