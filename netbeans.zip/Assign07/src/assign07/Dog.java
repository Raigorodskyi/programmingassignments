/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign07;

import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Dog extends Animal {
    private String suitFor;

    public Dog(String suitFor, String name, String gender, int age) {
        super(name, gender, age);
        this.suitFor = suitFor;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + super.hashCode();
        hash = 97 * hash + Objects.hashCode(this.suitFor);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Dog other = (Dog) obj;
        if (!Objects.equals(this.suitFor, other.suitFor)) {
            return false;
        }
        if (!super.equals(other)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %s\n", "Suit for", suitFor);
        
        return str;
    }

    public String getSuitFor() {
        return suitFor;
    }

    public void setSuitFor(String suitFor) {
        this.suitFor = suitFor;
    }
}
