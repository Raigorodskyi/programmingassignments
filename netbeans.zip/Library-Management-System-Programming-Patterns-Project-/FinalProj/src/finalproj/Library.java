/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalProj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Viktor Kostadinov
 */
class DBConnection {

    private static Connection con;

    public static Connection getSingleInstance() throws Exception {
        if (con == null) {
            con = getConnection();
        }
        return con;
    }

    public static Connection getConnection() throws Exception {

        Class.forName("org.sqlite.JDBC");
        String url = ""; // insert url here
        Connection con = DriverManager.getConnection(url);
        return con;

    }
}

class bookDBController {

    Connection con;

    public void booksTable() throws SQLException {

        String query = "CREATE TABLE Books "
                + "(SN TEXT PRIMARY KEY,"
                + " Title         TEXT    NOT NULL, "
                + " Author     TEXT     NOT NULL, "
                + " Publisher  TEXT      NOT NULL "
                + " Price   DECIMAL(20, 2), NOT NULL"
                + " Year       CHAR(100)"
                + " Quantity       CHAR(100)"
                + " Issued       CHAR(100), "
                + " AddedDate  TEXT)";
        Statement st = con.createStatement();
        st.executeUpdate("DROP table if exists Books");
        st.executeUpdate(query);
        System.out.println("Table Books created");
    }
}

class studentDBController {

    Connection con;

    public void studentsTable() throws SQLException {
        String query = "CREATE TABLE Students "
                + "(StudentID TEXT PRIMARY KEY,"
                + " Name          TEXT "
                + " Contact     TEXT)";

        Statement st = con.createStatement();
        st.executeUpdate("DROP table if exists Students");
        st.executeUpdate(query);
        System.out.println("Table Students created");
    }
}

class issuedBookDBController {

    Connection con;

    public void issuedBooksTable() throws SQLException {
        String query = "CREATE TABLE IssuedBooks"
                + "(ID INT(50) PRIMARY KEY,"
                + " SN  TEXT FOREIGN"
                + "FOREIGN KEY (SN) REFERENCES Books (SN)"
                + " StId     TEXT"
                + "FOREIGN KEY (StId) REFERENCES Students (StudentID)"
                + " STName TEXT"
                + " StudentContact  TEXT"
                + " IssueDate       TEXT)";

        Statement st = con.createStatement();
        st.executeUpdate("DROP table if exists IssuedBooks");
        st.executeUpdate(query);
        System.out.println("Table IssuedBooks created");
    }
}

public class Library {

    public static void main(String[] args) {
    }

}
