/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Lab8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
//        long startTime = System.currentTimeMillis();
//        System.out.println(countPrimeNums(2000000, 6000000));
//        long elapsedTime = System.currentTimeMillis() - startTime;
//        System.out.println(elapsedTime);
    
        long startTime1 = System.currentTimeMillis();
        Thread[] allThreades = new Thread[4];
        allThreades[0] = new Thread(new CountPrimes(2000000, 3000000));
        allThreades[1] = new Thread(new CountPrimes(3000000, 4000000));
        allThreades[2] = new Thread(new CountPrimes(4000000, 5000000));
        allThreades[3] = new Thread(new CountPrimes(5000000, 6000000));
//        for (int i = 0; i < 4; i++) allThreades[i].start();
//            
//        for (int i = 0; i < 4; i++) {
//            while (allThreades[i].isAlive()) {                
//                allThreades[i].join();
//            }
//        }
//        long elapsedTime1 = System.currentTimeMillis() - startTime1;
//        System.out.println("All done in " + elapsedTime1);
        
        
        long startTime2 = System.currentTimeMillis();
        // Create a thread pool with two threads
        ExecutorService executor = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 4; i++) {             
            executor.execute(allThreades[i]);
        }
        executor.shutdown();
        while (!executor.isTerminated()) {            
            
        }
        long elapsedTime2 = System.currentTimeMillis() - startTime2;
        System.out.println("All done in " + elapsedTime2);
    }
    
    public static boolean isPrime(int x) {
        int top = (int) Math.sqrt(x);
        for (int i = 2; i <= top; i++) {
            if (x % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    public static int countPrimeNums(int begin, int end) {
        int primeNums = 0;
        
        for (int i = begin; i <= end; i++) {
            if (isPrime(i)) {
                primeNums++;
            }
        }
        return primeNums;
    }
    
}

class CountPrimes implements Runnable {
    private int min;
    private int max;
    
    public CountPrimes(int min, int max) {
        this.min = min;
        this.max = max;
    }
    
    public static boolean isPrime(int x) {
        int top = (int) Math.sqrt(x);
        for (int i = 2; i <= top; i++) {
            if (x % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public void run() {
        int prime = 0;
        
        for (int i = min; i <= max; i++) {
            if(isPrime(i)) {
                prime++;
            }
        }
        System.out.println("Number of prime nums by " + Thread.currentThread().getName()
                + " in " + prime);
    }
    
    
}
