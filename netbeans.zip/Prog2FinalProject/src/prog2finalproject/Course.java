/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2finalproject;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Course implements Serializable {
    
    private String courseId;
    protected String courseName;
    private int maxStudent;
    private Teacher teacher;
    private ArrayList<Student> regsStudents;
    protected ArrayList<Double> finalScores;
    private static int nextCourseNo = 0;
    
    
    public Course() {
        this.courseId = String.format("C%04d", generateId());
        this.courseName = null;
        this.maxStudent = 0;
        this.teacher = null;
        this.regsStudents = null;
        this.finalScores = null;
    }
    
    public Course(String courseName, int maxStudent, Teacher teacher,
            ArrayList<Student> regsStudents, ArrayList<Double> finalScores) {
        this.courseId = String.format("C%04d", generateId());
        this.courseName = courseName;
        this.maxStudent = maxStudent;
        this.teacher = teacher;
        this.regsStudents = regsStudents;
        this.finalScores = finalScores;
    }
    
    public Course(Course course) {
        this.courseId = course.courseId;
        this.courseName = course.courseName;
        this.maxStudent = course.maxStudent;
        this.teacher = course.teacher;
        this.regsStudents = course.regsStudents;
        this.finalScores = course.finalScores;
    }

    public int generateId() {    
        return nextCourseNo++;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + Objects.hashCode(this.courseId);
        hash = 67 * hash + Objects.hashCode(this.courseName);
        hash = 67 * hash + this.maxStudent;
        hash = 67 * hash + Objects.hashCode(this.teacher);
        hash = 67 * hash + Objects.hashCode(this.regsStudents);
        hash = 67 * hash + Objects.hashCode(this.finalScores);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Course other = (Course) obj;
        if (this.maxStudent != other.maxStudent) {
            return false;
        }
        if (!Objects.equals(this.courseId, other.courseId)) {
            return false;
        }
        if (!Objects.equals(this.courseName, other.courseName)) {
            return false;
        }
        if (!Objects.equals(this.teacher, other.teacher)) {
            return false;
        }
        if (!Objects.equals(this.regsStudents, other.regsStudents)) {
            return false;
        }
        if (!Objects.equals(this.finalScores, other.finalScores)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-20s: %s\n", "Course ID", courseId);
        str += String.format("%-20s: %s\n", "Course Name", courseName);
        str += String.format("%-20s: %d\n", "Students Available", maxStudent);
        str += "Teacher:\n";
        str += String.format("%-5s %s: %s\n", " ", "Teacher ID", teacher.getUserId());
        str += String.format("%-5s %s: %s\n", " ", "Teacher Name", 
                teacher.getfName() + " " + teacher.getlName());
        
        return str;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getMaxStudent() {
        return maxStudent;
    }

    public void setMaxStudent(int maxStudent) {
        this.maxStudent = maxStudent;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public ArrayList<Student> getStudents() {
        return regsStudents;
    }

    public void setStudents(ArrayList<Student> regsStudents) {
        this.regsStudents = regsStudents;
    }

    public ArrayList<Double> getFinalScores() {
        return finalScores;
    }

    public void setFinalScores(ArrayList<Double> finalScores) {
        this.finalScores = finalScores;
    }
}
