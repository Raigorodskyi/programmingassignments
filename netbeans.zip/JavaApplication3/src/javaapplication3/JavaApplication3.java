/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author 2003i
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        //System.out.println(1986/100+1);
        //System.out.println(10 * 1986 % 100 / 10);
        //Scanner console = new Scanner(System.in); //memorize
        //3 methods for input
            //input an int
            /*System.out.println("Please enter a year: ");
            int year = console.nextInt();
            
            int century = year / 100 +1;
            int decade = year % 100 / 10 * 10;
            System.out.println("Year: " +year);
            System.out.println("Century " +century);
            System.out.println("Decade " +decade);
            
            System.out.printf("%s: %d\n", "Year", year); // %s for string %d for int \n for line
            System.out.printf("%s: %d\n", "Century", century);
            System.out.printf("%s: %d\n", "Decade", decade);
            String name = "Igor Raigorodskyi";
            int age = 17;
            String nation = "Israel/Ukraine";
            String department = "CS";
            String position = "Student";
            
            // print the info
            System.out.printf("%-15s:%s\n\n", "Attribute", "Value");
            System.out.printf("%-15s:%s\n\n", "Name", name);
            System.out.printf("%-15s:%s\n\n", "Age", age);
            System.out.printf("%-15s:%s\n\n", "Nationality", nation);
            System.out.printf("%-15s:%s\n\n", "Department", department);
            System.out.printf("%-15s:%s\n\n", "Position", position); */
            
            
            /*System.out.print("Please enter a number: ");
            double num = console.nextInt();
            //input a double
            //input a string
            System.out.println("Please enter your gender: ");
            String gender = console.next();
            System.out.println(gender);
            System.out.println("שם/שם משפחה");
            String name = console.next();
            System.out.println(name); */
            /*System.out.println("Enter two numbers: ");
            double num0 = console.nextDouble();
            double num11 = console.nextDouble();
            
            System.out.println(num0 / num11);
            System.out.println(num0 + "/" + num11 + "=" + (num0/num11));
            System.out.printf("%.2f/%.2f=%.2f", num0, num11, (num0/num11)); // %f floating */
            // %.2f okrugliajet do 2 cyfry poslie nulia
            
            /*int meatCheese = 3;
            double vege = 1.5;
            double kilo = 0.732;
            
            Scanner consol = new Scanner(System.in);
                System.out.println("Please enter the number of meet/cheese pizzas: ");
                int numCheeseMeat = consol.nextInt();
            Scanner cons = new Scanner(System.in);
                System.out.println("Please enter the number of vege pizzas: ");
                int numVege = cons.nextInt();
            Scanner con = new Scanner(System.in);
                System.out.println("Please enter the number of kilometers: ");
                double numKilo = con.nextDouble();
            System.out.printf("%-20s %5d\n", "Meat/cheese: ", numCheeseMeat);    
            System.out.printf("%-20s %5d\n", "Vege: ", numVege);
            System.out.printf("%-20s %5.1f\n", "Distance(km): ", numKilo);
            System.out.println("_______________________");
            System.out.printf("%-20s %5.2f\n", "%.2f", meatCheese*numCheeseMeat + vege*numVege + kilo*numKilo);
            // dont cross the red line too much (100 characters)
            //jesli jeszcze nie skonczyl pisac na tej linii, prosto przeniez wszystko na nastepna
            //nie trzeba miec more than 1 empty line in your code*/
            System.out.printf("Pi: %7.2f", 3.14159265354);
            
    }
        // TODO code application logic here
    }
    

