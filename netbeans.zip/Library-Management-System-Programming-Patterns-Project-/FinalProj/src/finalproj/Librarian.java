/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalProject;

/**
 *
 * @author Viktor Kostadinov
 */
public class Librarian {            // add a librarian class for the sake of system output, input?? (verification)

    private String librarianID;
    private String name;

    public Librarian(String librarianID, String name) {
        this.librarianID = librarianID;
        this.name = name;
    }

    public String getLibrarianID() {
        return librarianID;
    }

    public void setLibrarianID(String librarianID) {
        this.librarianID = librarianID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        String str = "";
        str += String.format("%s, %s", librarianID, name);
        return str;

    }

}
