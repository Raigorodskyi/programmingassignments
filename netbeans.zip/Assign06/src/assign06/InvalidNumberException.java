/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign06;

/**
 *
 * @author Igor Raigorodskyi
 */
public class InvalidNumberException extends RuntimeException {

    // default constructor
    public InvalidNumberException() {
    }
    
    // with String message
    public InvalidNumberException(String message) {
        super(message);
    }
}
