/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;
import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Item {
    protected String itemNo;
    protected double price;
    protected int amount;
    protected String category;
    protected boolean isGift;

    public Item() {
        this.itemNo = null;
        this.price = 0;
        this.amount = 0;
        this.category = null;
        this.isGift = false;
    }
    
    public Item(String itemNo, double price, int amount, String category, boolean isGift) {
        this.itemNo = itemNo;
        this.price = price;
        this.amount = amount;
        this.category = category;
        this.isGift = isGift;
    }
    
    public Item(Item item) {
        this.itemNo = item.itemNo;
        this.price = item.price;
        this.amount = item.amount;
        this.category = item.category;
        this.isGift = item.isGift;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.itemNo);
        hash = 47 * hash + (int) (Double.doubleToLongBits(this.price) ^ 
                (Double.doubleToLongBits(this.price) >>> 32));
        hash = 47 * hash + Objects.hashCode(this.category);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Item other = (Item) obj;
        if (Double.doubleToLongBits(this.price) != Double.doubleToLongBits(other.price)) {
            return false;
        }
        if (!Objects.equals(this.itemNo, other.itemNo)) {
            return false;
        }
        if (!Objects.equals(this.category, other.category)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-15s: %s\n", "Item Number", itemNo);
        str += String.format("%-15s: %.2f\n", "Price", price);
        str += String.format("%-15s: %d\n", "Amount of Item", amount);
        str += String.format("%-15s: %s\n", "Category", category);
        if (isGift) {
            str += String.format("%-15s: %s\n", "Is a Gift", "Yes");
        } else {
            str += String.format("%-15s: %s\n", "Is a Gift", "No");
        }
      
        return str;
    }

    public String getItemNo() {
        return itemNo;
    }

    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isIsGift() {
        return isGift;
    }

    public void setIsGift(boolean isGift) {
        this.isGift = isGift;
    }
}
