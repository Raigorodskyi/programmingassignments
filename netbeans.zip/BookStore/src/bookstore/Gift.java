/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

/**
 *
 * @author Igor Raigorodskyi
 */
public interface Gift {
    public abstract boolean pointToGift();
    public abstract boolean pointToGift(String type);
    public abstract boolean pointToGift(Item item);
}
