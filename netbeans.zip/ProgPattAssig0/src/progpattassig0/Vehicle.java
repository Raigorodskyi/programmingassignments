/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Vehicle {
    private int registrationNumber;
    private double maxVelocity;
    private double value;

    public Vehicle(int registrationNumber, double maxVelocity, double value) {
        this.registrationNumber = registrationNumber;
        this.maxVelocity = maxVelocity;
        this.value = value;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-15s: %d\n", "Registration Number", registrationNumber);
        str += String.format("%-15s: %.2f\n", "Maximum Velocity", maxVelocity);
        str += String.format("%-15s: %.2f\n", "Value", value);
        
        return str;
    }

    public int getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(int registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public double getMaxVelocity() {
        return maxVelocity;
    }

    public void setMaxVelocity(double maxVelocity) {
        this.maxVelocity = maxVelocity;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
