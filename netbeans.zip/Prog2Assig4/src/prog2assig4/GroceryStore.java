/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class GroceryStore {
    private ArrayList<User> users = new ArrayList<>();
    private ArrayList<Product> products = new ArrayList<>();
    
    public GroceryStore() {
        this.products = null;
        this.users = null;
    }
    
    public GroceryStore(ArrayList<Product> products, ArrayList<User> users) {
        this.products = products;
        this.users = users;
    }
    
    public GroceryStore(GroceryStore groceryStore) {
        this.products = groceryStore.products;
        this.users = groceryStore.users;
    }
    
    /**
     * Adds a user to the list of users
     * @param user is the user to add
     */
    public void addUser(User user) {
        users.add(user);
    }
    
    /**
     * Adds a product to the list of products
     * @param product is the product to add 
     */
    public void addProduct(Product product) {
        products.add(product);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GroceryStore other = (GroceryStore) obj;
        if (!Objects.equals(this.users, other.users)) {
            return false;
        }
        if (!Objects.equals(this.products, other.products)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%s: %d", "Total number of products", products.size());
        str += String.format("%s: %d", "Total users in the system", users.size());
        
        return str;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }
}
