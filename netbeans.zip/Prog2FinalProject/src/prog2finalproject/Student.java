/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2finalproject;

import java.util.ArrayList;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Student extends User {
    
    protected ArrayList<Course> regsCourses = new ArrayList<>();
    private static int nextStudentNo = 0;
    
    public Student() {
        super();
        super.userId = String.format("S%04d", generateId());
        this.regsCourses = null;
    }

    public Student(String password, String fName, String lName,
            ArrayList<Course> regsCourses) {
        super(password, fName, lName);
        super.userId = String.format("S%04d", generateId());
        this.regsCourses = regsCourses;
    }

    public Student(User user, ArrayList<Course> regsCourses) {
        super(user);
        this.regsCourses = regsCourses;
    }

    @Override
    public int generateId() {    
        return nextStudentNo++;
    }
    
    @Override
    public String toString() {
        String str = "";
        
        str += super.toString(); 
        str += "Courses registered:\n";
        for (Course regsCourse : regsCourses) {
            str += String.format("%-5s %s", "", regsCourse.getCourseName());
        }
        
        return str;
    }

    public ArrayList<Course> getRegsCourses() {
        return regsCourses;
    }

    public void setRegsCourses(ArrayList<Course> regsCourses) {
        this.regsCourses = regsCourses;
    }

    public static int getNextStudentNo() {
        return nextStudentNo;
    }

    public static void setNextStudentNo(int nextStudentNo) {
        Student.nextStudentNo = nextStudentNo;
    }
}
