/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2finalproject;

import java.util.ArrayList;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Teacher extends User {
    
    private ArrayList<Course> teachingCourses;
    private static int nextTeacherNo = 0;
    
    public Teacher() {
        super();
        super.userId = String.format("T%04d", generateId());
        this.teachingCourses = null;
    }

    public Teacher(ArrayList<Course> teachingCourses, String password, String fName, String lName) {
        super(password, fName, lName);
        super.userId = String.format("T%04d", generateId());
        this.teachingCourses = teachingCourses;
    }

    public Teacher(ArrayList<Course> teachingCourses, User user) {
        super(user);
        this.teachingCourses = teachingCourses;
    }

    @Override
    public int generateId() {    
        return nextTeacherNo++;
    }
    
    @Override
    public String toString() {
        String str = "";
       
        str += super.toString();
        str += "Courses Teaching: \n";
        for (Course teachingCourse : teachingCourses) {
            str += String.format("%-5s %s", "", teachingCourse.getCourseName());
        }
        
        return str;
    }

    public ArrayList<Course> getTeachingCourses() {
        return teachingCourses;
    }

    public void setTeachingCourses(ArrayList<Course> teachingCourses) {
        this.teachingCourses = teachingCourses;
    }
    
}
