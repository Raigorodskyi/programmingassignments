/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 *
 * @author 2003i
 */
public class Recursion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(removeVowel("Hello!"));
    }
    
    public static int sum(int num) {
        int sum = 0;
        for (int i = 0; i < num; i++) {
            sum += i;
        }
        return sum;
    }
    
    public static int sumRecursion(int num) {
        // base base
        if (num == 0) {
            return 0;
        }
        // general pattern
        return sumRecursion(num - 1) + num - 1;
    }
    
    public static int factorial(int num) {
        if(num == 0 || num == 1){
            return 1;
        }
        return factorial(num - 1) * num;
    }

    public static int fibonacciRecursion(int num) {
        if (num == 0 || num == 1) {
            return num;
        }
        return fibonacciRecursion(num - 2) + fibonacciRecursion(num - 1);
    }
    
    public static int fibonacci(int num) {
        int f0 = 0;
        int f1 = 1;
        int result = 0;
        
        for (int i = 2; i <= num; i++) {
            result = f0 + f1;
            f0 = f1;
            f1 = result;
        }
        return result;
    }
    
    public static String reverse(String str) {
        String strRev = "";
        
        for (int i = str.length() - 1; i >= 0; i--) {
            strRev += str.charAt(i);
        }
        
        return strRev;
    }
    
    public static String reverseRecursion(String str) {
        if (str.length() == 1 || str.isEmpty()) {
            return str;
        }
        
        return reverseRecursion(str.substring(1)) + str.charAt(0);
    }

//    public static boolean isPalindrome(String str) {
//        return str.equals(reverse(str));
//    }
//    
//    public static boolean isPalindrome1(String str) {
//        int numSameLetters = 0;
//        
//        for (int i = 0; i < Math.ceil(str.length() / 2); i++) {
//            if (str.charAt(i) == str.charAt(str.length() - 1 - i)) {
//                numSameLetters++;
//            }
//        }
//            return numSameLetters == Math.ceil(str.length() / 2);
//    }
   
    public static boolean isPalidrome(String str) {
        for(int i = 0; i < Math.ceil(str.length() / 2); i++) {
            if(str.charAt(i) != str.charAt(str.length() - 1 - i)) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isPalidromeRecursion(String str) {
        if(str.length() <= 1){
             return true;
        }
        return str.charAt(0) == str.charAt(str.length() - 1) && 
                isPalidromeRecursion(str.substring(1, str.length() -1));
    }
    
    public static String removeVowel(String str) {
        String strNoVowel = "";
        String vowels = "aeoiu";
        for (int i = 0; i < str.length(); i++) {
            if ("AEIOUaeiou".indexOf(str.charAt(i)) == -1) {
                strNoVowel += str.charAt(i);
            }
        }
        return strNoVowel;
    }
    
//    public static String removeVowelRecursion(String str) {
//        if (str.isEmpty()) {
//            return str;
//        }
//    }
}
