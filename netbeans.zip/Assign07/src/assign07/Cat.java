/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign07;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Cat extends Animal {
    private boolean longFur;

    public Cat(boolean longFur, String name, String gender, int age) {
        super(name, gender, age);
        this.longFur = longFur;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + super.hashCode();
        hash = 79 * hash + (this.longFur ? 1 : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cat other = (Cat) obj;
        if (this.longFur != other.longFur) {
            return false;
        }
        if (!super.equals(other)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        str += super.toString();
        if (longFur) {
            str += String.format("%-15s: %s\n", "Fur", "long");
        } else {
            str += String.format("%-15s: %s\n", "Fur", "short");
        }
 
        return str;
    }

    public void setLongFur(boolean longFur) {
        this.longFur = longFur;
    }

    public boolean isLongFur() {
        return longFur;
    }
}
