/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;

/**
 *
 * @author Igor Raigorodskyi
 */
public class TaxableHouse extends House implements Taxable {

    public TaxableHouse(double area, String location, boolean inCity, double estimatedValue) {
        super(area, location, inCity, estimatedValue);
    }

    @Override
    public double valueTax() {
        if (isInCity()) {
            return (getEstimatedValue() /1000) * 5 + (5 * getArea());
        } else {
            return (getEstimatedValue() / 1000) * 3;
        }
    }
    
    @Override
    public String toString() {
        String str = "";
        
        str += "Taxable House\n";
        str += super.toString();
        str += String.format("%-15s: %.2f\n", "Tax", valueTax());
        
        return str;
    }
}

