/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;
import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Cd extends Item {
    protected String name;
    protected Person artist;
    private static int nextCdNo = 0;

    public Cd() {
        super();
        this.itemNo = String.format("C%04d", generateId());
        this.name = null;
        this.artist = null;
    }

    public Cd(String name, Person artist, String itemNo, double price, int amount, 
            String category, boolean isGift) {
        super(itemNo, price, amount, category, isGift);
        this.itemNo = String.format("C%04d", generateId());
        this.name = name;
        this.artist = artist;
        if (category.equalsIgnoreCase("pop")) {
            this.category = "pop";
        }
        else if (category.equalsIgnoreCase("classic")) {
            this.category = "classic";
        }
        else if (category.equalsIgnoreCase("jazz")) {
            this.category = "jazz";
        }
        else if (category.equalsIgnoreCase("new age")) {
            this.category = "new age";
        }
        else if (category.equalsIgnoreCase("sound track")) {
            this.category = "sound track";
        }
        else {
            this.category = "others";
        }
    }

    public Cd(Cd cd) {
        super(cd);
        this.name = cd.name;
        this.artist = cd.artist;
    }
    
    public static int generateId(){
        return nextCdNo++;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.name);
        hash = 37 * hash + Objects.hashCode(this.artist);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cd other = (Cd) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.artist, other.artist)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
       String str = "";
       
       str += super.toString();
       str +=  String.format("%-15s: %s\n", "Name", name);
       str +=  String.format("%-15s: %s\n", "Artist", artist.getName());
       
       return str;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Person getArtist() {
        return artist;
    }

    public void setArtist(Person artist) {
        this.artist = artist;
    }
}
