/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author 2003i
 */
public abstract class Shape {
     /**
     * Calculates the area of a shape
     *
     * @return the area of a shape
     */
    public abstract double calcArea();      // abstract method, with no body
    
    private static void print(Shape shape) {
        System.out.println(shape);
    } 
    
    @Override 
    public String toString() {
        return "Mashehu ani gam lo yodea ma ani";
    }

    /**
     * Calculates the perimeter of a shape
     *
     * @return the perimeter of a shape
     */
    public abstract double calcPerimeter();      // abstract method, with no body

    /**
     * Normal methods are allowed
     */
    private void print() {
        System.out.println("hello");
    }

    public static void main(String[] args) {
        Square s = new Square();
        Square r = new Square();
//        Shape sh = new Shape();
        Square sh1 = new Square();
        Triangle t = new Triangle();
        System.out.println("Area = " + t.calcPerimeter());
        Ellipse e = new Ellipse();
        Shape.print(e);
    }
}
