/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author 2003i
 */
public class Prog2Assig4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Food apple = new Food(5, "Apple", 2, 1);
        Food chocolate = new Food(30, "Choc", 4, 5);
        Food sugar = new Food(35, "Sugar", 3, 6);
        Food milk = new Food(10, "Milk", 5, 3);
        NonFoodProduct cup = new NonFoodProduct("Cup", 3, 5);
        Customer cus = new Customer(2, 11, 30);
         ArrayList<Product> products = new ArrayList<>(Arrays.asList(new Product[] {apple, chocolate, sugar, milk, cup}));
        
        System.out.println(cup.toString());
        System.out.println(products.toString());
        
    }
    
}
