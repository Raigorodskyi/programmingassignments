/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign07;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Shelter {
    private static ArrayList<Animal> animals = new ArrayList<>();
    
    /**
     * Adds an animal and serializes the data
     * @param animal animal to add
     */
    public void addAnimal(Animal animal) {
        animals.add(animal);
        serializeAnimals("animals.ser");
    }
    
    /**
     * Removes an animal and serializes the data
     * @param animal 
     */
    public void removeAnimal(Animal animal) {
        animals.remove(animal);
        serializeAnimals("animals.ser");
    }
    
    /**
     * Searches for unhealthy animals
     * @return ArrayList of unhealthy animals
     */
    public static ArrayList<Animal> searchUnhealthyAnimals() {
        ArrayList<Animal> unhealthyAnimals = new ArrayList<>();
        for (Animal animal : animals) {
            if (animal.getHealthStatus() > 0) {
                unhealthyAnimals.add(animal);
            }
        }
        return unhealthyAnimals;
    }
    
    /**
     * Serializes animals
     * @param path the path of the file
     */
    public static void serializeAnimals(String path) {
        try (FileOutputStream fos = new FileOutputStream(path)) {
             ObjectOutputStream oos = new ObjectOutputStream(fos);
             oos.writeObject(animals);
        } catch (Exception e) {
        }
    }
    
    /**
     * Deserializes animals 
     * @param path the path of the file
     * @return the deserialized object
     */
    public static Object deserializeAnimals(String path) {
        try (FileInputStream fis = new FileInputStream(path)) {
            ObjectInputStream ois = new ObjectInputStream(fis);
            return ois.readObject();
        } catch (Exception e) {
        }
        return null; 
    }
    
    /**
     * Reads the .csv file and returns all animal in collection
     * @param path the path of the file
     * @return ArrayList of read animals
     */
    public static ArrayList<Animal> readAnimalData(String path) {
        File file = new File(path);
        ArrayList<Animal> animalsToRead = new ArrayList<>();
        
        try ( Scanner input = new Scanner(file)) {
            input.nextLine();           
            while (input.hasNext()) {           
                String row = input.nextLine();
                String[] data = row.split(",");    
                // distributing the attributes that both Cat and Dog classes have
                String id = data[0];
                String name = toTitleCase(data[1]);
                String type = toTitleCase(data[2]);
                String gender = toTitleCase(data[3]);
                int age = Integer.parseInt(data[4]);
                int healthStatus = Integer.parseInt(data[5]);
                //distributing fur for Cat and suitFor for Dog
                if (type.equalsIgnoreCase("cat")) {
                    Cat animal = new Cat(true, name, gender, age);
                    if (data[6].equalsIgnoreCase("long")) {
                       animal.setLongFur(true);
                    }else {
                        animal.setLongFur(false);
                    }
                    animal.setId(id);
                    animal.setType(type);
                    animal.setHealthStatus(healthStatus);
                    animalsToRead.add(animal);
                }else {
                    Dog animal = new Dog(data[6], name, gender, age);
                    animal.setId(id);
                    animal.setType(type);
                    animal.setHealthStatus(healthStatus);
                    animalsToRead.add(animal);
                }
            }
        } catch (IOException e) {
            System.out.println(String.format("File %s does not exist", path));
        }
        return animalsToRead;
    }
    
    /**
     * toTitleCase method
     * @param str to convert to title case
     * @return string in title case
     */
    public static String toTitleCase(String str) {
        return Character.toUpperCase(str.charAt(0)) + str.substring(1).toLowerCase();
    }
    
    /**
     * Writes the ArrayList of Animal to the .csv file
     * @param path the path of the file
     */
    public static void writeAnimalFile(String path) {
        File file = new File(path);

        try ( FileWriter fw = new FileWriter(file)) {       // I did not put "true" 
                //so the data would be updated in the file each time the method is called
            fw.write("id,name,type,gender,age,healthStatus,house/apartment,fur\n"); //the header
            for (Animal animal : animals) {
                fw.write(animal.getId() + ",");
                fw.write(animal.getName() + ",");
                fw.write(animal.getType() + ",");
                fw.write(animal.getGender() + ",");
                fw.write(animal.getAge() + ",");
                fw.write(animal.getHealthStatus() + ",");
                if (animal.getType().equalsIgnoreCase("cat")) {
                    Cat cat = (Cat)animal;
                    fw.write(",");  // the comma would skip suitFor
                    if (cat.isLongFur()) {
                       fw.write("long");
                    } else {
                       fw.write("short");
                    }
               }else{
                    Dog dog = (Dog)animal;
                    fw.write(dog.getSuitFor());
                }
                fw.write("\n");
            }

        } catch (IOException e) {
            System.out.println(String.format("%s: %s", e.getClass(), e.getMessage()));
        }
    }
    
    /**
     * Writes the ArrayList of Animal to the .csv file (All Cats and Dogs whose suitFor== @param suitFor)
     * @param path the path of the file
     * @param suitFor suitFor of dog
     */
    public static void writeAnimalFile(String path, String suitFor) {
        File file = new File(path);

        try ( FileWriter fw = new FileWriter(file)) {
            fw.write("id,name,type,gender,age,healthStatus,house/apartment,fur\n"); //the header
            for (Animal animal : animals) {
                if (animal.getType().equalsIgnoreCase("cat")) {
                    Cat cat = (Cat)animal;
                    fw.write(animal.getId() + ",");
                    fw.write(cat.getName() + ",");
                    fw.write(cat.getType() + ",");
                    fw.write(cat.getGender() + ",");
                    fw.write(cat.getAge() + ",");
                    fw.write(cat.getHealthStatus() + ",,");
                    if (cat.isLongFur()) {
                       fw.write("long\n");
                    } else {
                       fw.write("short\n");
                    }
                }else {
                    Dog dog = (Dog)animal;
                    if (dog.getSuitFor().equalsIgnoreCase(suitFor)) {
                        fw.write(dog.getId() + ",");
                        fw.write(dog.getName() + ",");
                        fw.write(dog.getType() + ",");
                        fw.write(dog.getGender() + ",");
                        fw.write(dog.getAge() + ",");
                        fw.write(dog.getHealthStatus() + ",");
                        fw.write(dog.getSuitFor() + "\n");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println(String.format("%s: %s", e.getClass(), e.getMessage()));
        }
    }
}
