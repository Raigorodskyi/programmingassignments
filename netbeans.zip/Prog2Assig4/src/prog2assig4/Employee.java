/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;

import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public abstract class Employee extends User implements Working {
    private String position;
    private double salary;
    private int monthsWorked;
    private double workingHours;

    public Employee() {
        super();
        this.position = null;
        this.salary = 0;
        this.monthsWorked = 0;
        this.workingHours = 0;
    }

    public Employee(String name, String gender, String dateOfBirth, String email,
            String position, double salary, int monthsWorked, int workingHours) {
        super(name, gender, dateOfBirth, email);
        this.position = position;
        this.salary = salary;
        this.monthsWorked = monthsWorked;
        this.workingHours = workingHours;
    }

    public Employee(Employee employee) {
        super(employee);
        this.position = employee.position;
        this.salary = employee.salary;
        this.monthsWorked = employee.monthsWorked;
        this.workingHours = employee.workingHours;
    }
    
    public void increaseSalary() {
        if (monthsWorked >= 18) {
            salary *= 1.1;
            monthsWorked -= 18;     // the 18 months worked at the store were 
                                // transformed to a 10% increase to the salary
        }
    }
    
    @Override
    public void checkWorkingHours() {
        System.out.println("Your working hours for this week: " + workingHours);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Employee other = (Employee) obj;
        if (Double.doubleToLongBits(this.salary) != Double.doubleToLongBits(other.salary)) {
            return false;
        }
        if (this.monthsWorked != other.monthsWorked) {
            return false;
        }
        if (this.workingHours != other.workingHours) {
            return false;
        }
        if (!Objects.equals(this.position, other.position)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %s\n", "Position", position);
        str += String.format("%-15s: %f\n", "Salary", salary);
        str += String.format("%-15s: %d\n", "Months Worked", monthsWorked);
        str += String.format("%-15s: %f\n", "Working Hours", workingHours);
        
        return str;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getMonthsWorked() {
        return monthsWorked;
    }

    public void setMonthsWorked(int monthsWorked) {
        this.monthsWorked = monthsWorked;
    }

    public double getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(double workingHours) {
        this.workingHours = workingHours;
    }
}
