/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;
import java.util.Comparator;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Student implements Comparable<Student>{
    private String name;
    private double score;

    public Student(String name, double score) {
        this.name = name;
        this.score = score;
    }

    @Override
    public String toString() {
       String str = "";
       
       str += "Student\n";
       str += String.format("%-15s: %s\n", "Name", name);
       str += String.format("%-15s: %.2f\n\n", "Score", score);
       
       return str;
    }

    @Override
    public int compareTo(Student t) {
        return Double.compare(this.score, t.getScore());
    }
    
    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setScore(double score) {
        this.score = score;
    }
}

class CompareStudentName implements Comparator<Student> { 
    @Override
    public int compare(Student o1, Student o2) {
        return o1.getName().compareTo(o2.getName());
    }
}