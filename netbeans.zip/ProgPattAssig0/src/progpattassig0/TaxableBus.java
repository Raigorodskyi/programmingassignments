/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;

/**
 *
 * @author Igor Raigorodskyi
 */
public class TaxableBus extends Bus implements Taxable {

    public TaxableBus(int numberOfSeats, int registrationNumber, double maxVelocity, double value) {
        super(numberOfSeats,registrationNumber, maxVelocity, value);
    }

    @Override
    public double valueTax() {
        return (getValue() / 10) + (100 * getNumberOfSeats());
    }

    @Override
    public String toString() {
        String str = "";
        
        str += "Taxable Bus\n";
        str += super.toString();
        str += String.format("%-15s: %.2f\n", "Tax", valueTax());
        
        return str;
    }
}
