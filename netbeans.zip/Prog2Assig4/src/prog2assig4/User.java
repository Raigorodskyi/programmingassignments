/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;

import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class User {
    private String name;
    private String gender;
    private String dateOfBirth;
    private String email;

    public User() {
        this.name = null;
        this.gender = null;
        this.dateOfBirth = null;
        this.email = null;
    }
    
    public User(String name, String gender, String dateOfBirth, String email) {
        this.name = name;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
    }
    
    public User(User user) {
        this.name = user.name;
        this.gender = user.gender;
        this.dateOfBirth = user.dateOfBirth;
        this.email = user.email;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.gender, other.gender)) {
            return false;
        }
        if (!Objects.equals(this.dateOfBirth, other.dateOfBirth)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-15s: %s\n", "Name", name);
        str += String.format("%-15s: %s\n", "Gender", gender);
        str += String.format("%-15s: %s\n", "Date of Birth", dateOfBirth);
        str += String.format("%-15s: %s\n", "Email", email);
        
        return str;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
