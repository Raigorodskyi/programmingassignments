/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;

import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Product {
    private String name;
    private double price;
    private int daysInStore;

     public Product() {
        this.name = null;
        this.price = 0;
        this.daysInStore = 0;
    }
    
    public Product(String name, double price, int daysInStore) {
        this.name = name;
        this.price = price;
        this.daysInStore = daysInStore;
    }
    
     public Product(Product product) {
        this.name = product.name;
        this.price = product.price;
        this.daysInStore = product.daysInStore;
    }
    
     /**
      * Decreases the price of a product if it stays in the store for too long
      */
    public void updatePrice() {
        if (daysInStore >= 7 && daysInStore < 14) {
            price *= 0.75;
        }
        if (daysInStore >= 14 && daysInStore < 25) {
            price *= 0.5;
        }
        if (daysInStore >= 25) {
            price *= 0.25;
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Product other = (Product) obj;
        if (Double.doubleToLongBits(this.price) != Double.doubleToLongBits(other.price)) {
            return false;
        }
        if (this.daysInStore != other.daysInStore) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-15s: %s\n", "Product", name);
        str += String.format("%-15s: %.2f\n", "Price", price);
        str += String.format("%-15s: %d\n", "Time in Store", daysInStore);

        return str;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getDaysInStore() {
        return daysInStore;
    }

    public void setDaysInStore(int daysInStore) {
        this.daysInStore = daysInStore;
    }
}
