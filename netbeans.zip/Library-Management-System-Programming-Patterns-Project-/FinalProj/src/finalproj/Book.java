/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalProj;

import java.util.Map;

/**
 *
 * @author Viktor Kostadinov
 */
public class Book {

    private String SN;
    private String title;
    private String author;
    private String publisher;
    private double price;
    private int releaseYear;                   // add year since we also want to search year for book?
    private int quantity;
    private int issuedQuantity;
    private String dateOfPurchase;          // date of purchase for book? and addedDate in table... could we maybe just brand them as the same for both?

    public Book(String SN, String title, String author, String publisher, double price, int releaseYear, int quantity, int issuedQuantity, String dateOfPurchase) {
        this.SN = SN;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.price = price;
        this.releaseYear = releaseYear;
        this.quantity = quantity;
        this.issuedQuantity = issuedQuantity;
        this.dateOfPurchase = dateOfPurchase;
    }

    public String getSN() {
        return SN;
    }

    public void setSN(String SN) {
        this.SN = SN;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(int issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public String getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(String dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    @Override
    public String toString() {
        String str = "";
        str += String.format("Book\n  Serial Number: %s\n"
                + "  Title: %s\n  Author: %s\n  Publisher: %s\n  Price: %.2f\n  Release Year: %d\n"
                + "  Quantity: %d\n  Issued Quantity: %d\n  Date of Purchase: %s\n\n", SN, title, author, 
                publisher, price, releaseYear, quantity, issuedQuantity, dateOfPurchase);
        return str;
    }

    public Book addBook(Book book) {
        return null;
    }

    public Boolean issueBook(Book book, Student student) {
        return false;
    }

    public Boolean returnBook(Book book, Student student) {
        return false;
    }

    public static Map<String, String> viewCatalog() {
        return null;
    }

    public static Map<String, String> viewIssuedBooks() {
        return null;
    }

}