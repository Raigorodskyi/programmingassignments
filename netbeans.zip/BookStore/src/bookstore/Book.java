/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Book extends Item {
    protected String title;
    protected ArrayList<Person> authors;
    private static int nextBookNo = 0;

    public Book() {
        super();
        this.itemNo = String.format("B%04d", generateId());
        this.title = null;
        this.authors = null;
    }

    public Book(String title, ArrayList<Person> authors, String itemNo,
            double price, int amount, String category, boolean isGift) {
        super(itemNo, price, amount, category, isGift);
        this.itemNo = String.format("B%04d", generateId());
        if (category.equalsIgnoreCase("history")) {
            this.category = "history";
        }
        else if (category.equalsIgnoreCase("science")) {
            this.category = "science";
        }
        else if (category.equalsIgnoreCase("cook")) {
            this.category = "cook";
        }
        else if (category.equalsIgnoreCase("sports")) {
            this.category = "sports";
        }
        else if (category.equalsIgnoreCase("art")) {
            this.category = "art";
        }
        else {
            this.category = "others";
        }
        this.title = title;
        this.authors = authors;
    }

    public Book(Book book) {
        super(book);
        this.title = book.title;
        this.authors = book.authors;
    }
    
    public static int generateId(){
        return nextBookNo++;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.title);
        hash = 17 * hash + Objects.hashCode(this.authors);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Book other = (Book) obj;
        if (!Objects.equals(this.title, other.title)) {
            return false;
        }
        if (!Objects.equals(this.authors, other.authors)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String str = "";
        // creating a string that would contain the names of all autors
        String authorsNames = "";
        for (int i = 0; i < this.authors.size() - 1; i++) {
            authorsNames += this.authors.get(i).getName() + ", ";
        }
        for (int i = this.authors.size() - 1; i < this.authors.size(); i++) {
            authorsNames += this.authors.get(i).getName();
        }
        str += super.toString();
        str += String.format("%-15s: %s\n", "Book Title", title);
        str += String.format("%-15s: %s\n", "Authors", authorsNames);
        
        return str;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<Person> getAuthors() {
        return authors;
    }

    public void setAuthors(ArrayList<Person> authors) {
        this.authors = authors;
    }    
}
