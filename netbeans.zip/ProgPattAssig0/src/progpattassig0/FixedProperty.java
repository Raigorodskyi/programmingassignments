/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;

/**
 *
 * @author Igor Raigorodskyi
 */
public class FixedProperty {
    private String location;
    private boolean inCity;
    private double estimatedValue;

    public FixedProperty(String location, boolean inCity, double estimatedValue) {
        this.location = location;
        this.inCity = inCity;
        this.estimatedValue = estimatedValue;
    }
    
    public FixedProperty(String location) {
        this.location = location;
        this.inCity = true;
        this.estimatedValue = 1000000;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += String.format("%-15s: %s\n", "Location", location);
        if (inCity) {
            str += "Is in city\n";
        } else {
            str += "Is not in city\n";
        }
        str += String.format("%-15s: %.2f\n", "Estimated Value", estimatedValue);
        
        return str;
    }

    public String getLocation() {
        return location;
    }

    public boolean isInCity() {
        return inCity;
    }

    public void setInCity(boolean inCity) {
        this.inCity = inCity;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getEstimatedValue() {
        return estimatedValue;
    }

    public void setEstimatedValue(double estimatedValue) {
        this.estimatedValue = estimatedValue;
    }
}
