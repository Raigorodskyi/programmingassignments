/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2assig4;

/**
 *
 * @author Igor Raigorodskyi
 */
public class Customer {
    private int clientLevel;
    private int points;
    private double moneySpent;

    public Customer() {
        this.clientLevel = 1;
        this.points = 0;
        this.moneySpent = 0;
    }
    
    public Customer(int clientLevel, int points, double moneySpent) {
        this.clientLevel = clientLevel;
        this.points = points;
        this.moneySpent = moneySpent;
    }
    
    public Customer(Customer customer) {
        this.clientLevel = customer.clientLevel;
        this.points = customer.points;
        this.moneySpent = customer.moneySpent;
    }
    
    /**
     * for every 100$ spent at the store, customer would get 1 point
     */
    public void increasePoints() {
        if (moneySpent >= 100) {
            points ++;
            moneySpent -= 100;      // so the 100$ are transferred to 1 point 
        }
    }
    
    public void updateClientLevel() {
        if (points >= 20) {
            clientLevel++;
            points -= 20;          // so the 20 points are transferred to +1 level
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Customer other = (Customer) obj;
        if (this.clientLevel != other.clientLevel) {
            return false;
        }
        if (this.points != other.points) {
            return false;
        }
        if (Double.doubleToLongBits(this.moneySpent) != Double.doubleToLongBits(other.moneySpent)) {
            return false;
        }
        return true;
    }
    
    public String toString() {
        String str = "";
        
        str += super.toString();
         str += String.format("%-15s: %d\n", "Client Level", clientLevel);
         str += String.format("%-15s: %d\n", "Points", points);
         str += String.format("%-15s: %d\n", "Money Spent", moneySpent);
         
         return str;
    }

    public int getClientLevel() {
        return clientLevel;
    }

    public void setClientLevel(int clientLevel) {
        this.clientLevel = clientLevel;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public double getMoneySpent() {
        return moneySpent;
    }

    public void setMoneySpent(double moneySpent) {
        this.moneySpent = moneySpent;
    }
}
