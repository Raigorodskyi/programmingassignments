/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment6;

/**
 *
 * @author 2003i
 */
public class Assignment6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*int days = 1;
        Calendar b = new Calendar(2020,11,23);
        Calendar c = new Calendar(2003,7,8);
        System.out.println(c);
        System.out.println(b);
        for (int i = 1; i < 57; i++) {
            c.increaseDay();
            System.out.println(c);
        }
        System.out.println(c.getDaysInMonth());*/
    }
    
}
