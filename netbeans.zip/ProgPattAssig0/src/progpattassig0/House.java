/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progpattassig0;

/**
 *
 * @author Igor Raigorodskyi
 */
public class House extends FixedProperty {
    private double area;

    public House(double area, String location, boolean inCity, double estimatedValue) {
        super(location, inCity, estimatedValue);
        this.area = area;
    }

    @Override
    public String toString() {
        String str = "";
        
        str += super.toString();
        str += String.format("%-15s: %.2f\n", "Area", area);
        
        return str;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }
}
